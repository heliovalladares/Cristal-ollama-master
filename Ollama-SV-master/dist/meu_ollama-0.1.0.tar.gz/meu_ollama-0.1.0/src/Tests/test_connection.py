import unittest
from pymongo import MongoClient
from unittest.mock import patch
from ..DataBusiness import MongoDBConnectionFactory, load_variables

class TestMongoDBConnection(unittest.TestCase):

    @patch('DataBusiness.index.load_variables')
    @patch('pymongo.MongoClient')
    def test_mongodb_connection(self, mock_mongo_client, mock_load_variables):
        # Defina os valores de ambiente simulados para o teste
        mock_load_variables.return_value = {
            "uri": "mongodb+srv://test_username:test_password@test_host/",
            "database": "test_database"
        }

        # Simule o objeto MongoClient
        mock_client_instance = mock_mongo_client.return_value

        # Chame o método para obter o banco de dados
        db = MongoDBConnectionFactory.get_db()

        # Verifique se MongoClient foi inicializado com a URI correta
        mock_mongo_client.assert_called_once_with("mongodb+srv://test_username:test_password@test_host/")

        # Verifique se o método get_db retornou o banco de dados correto
        self.assertEqual(db, mock_client_instance["test_database"])

if __name__ == '__main__':
    unittest.main()
