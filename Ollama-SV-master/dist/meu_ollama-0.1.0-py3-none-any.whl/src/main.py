import ollama
formatted_prompt = input('Faça uma pergunta: ')

result = ollama.chat(model='llama3', stream=True, messages=[{'role': 'user', 'content': formatted_prompt}])
#print(result['message']['content'])

for chunk in result:
  print(chunk['message']['content'], end='', flush=True)
